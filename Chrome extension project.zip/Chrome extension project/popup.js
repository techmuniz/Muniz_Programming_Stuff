document.addEventListener('DOMContentLoaded', function() {
  const button = document.getElementById('clickButton');
  
  button.addEventListener('click', function() {
    alert("Botão clicado!"); // Evento de alerta para teste
    
    const targetButton = document.querySelector('[data-test-component="hide-btn"]');
    
    if (targetButton) {
      targetButton.click();
    }
  });
});
